<link rel="icon" type="image/x-icon" href="{{asset('assets/img/favicon/favicon.ico')}}" />
<link
  href="https://fonts.googleapis.com/css2?family=Public+Sans:ital,wght@0,300;0,400;0,500;0,600;0,700;1,300;1,400;1,500;1,600;1,700&display=swap"
  rel="stylesheet"
/>
<link rel="stylesheet" href="{{asset('assets/vendor/fonts/boxicons.css')}}" />
<link rel="stylesheet" href="{{asset('assets/vendor/css/core.css')}}"/>
<link rel="stylesheet" href="{{asset('assets/vendor/css/theme-default.css')}}"/>
<link rel="stylesheet" type="text/css" href="{{asset('assets/css/manager.css')}}">
<!-- Select2 -->
<link rel="stylesheet" href="{{asset('assets/css/select2.min.css')}}" />
<link rel="stylesheet" href="{{asset('assets/css/select2-bootstrap4.css')}}" />
<!-- datatable css -->
<link rel="stylesheet" type="text/css" href="{{asset('assets/datatable/css/dataTables.bootstrap5.min.css')}}">
<script src="{{asset('assets/vendor/js/helpers.js')}}" type="text/javascript"></script>
<script src="{{asset('assets/js/config.js')}}" type="text/javascript"></script>